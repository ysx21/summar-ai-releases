<?php
/**
 * Plugin Name: Summar AI
 * Description: Power your content with AI. Ask questions about the current post/page and get answers grounded in its content.
 * Version: 0.1.7
 * GitHub Plugin URI: https://github.com/ysx21/summar-ai
 * Primary Branch: main
 * Author: Summar AI
 * Text Domain: summar-ai
 * Domain Path: /languages
 */

if ( ! defined('ABSPATH') ) { exit; }

require_once plugin_dir_path(__FILE__) . 'includes/openai.php';
require_once plugin_dir_path(__FILE__) . 'includes/query-logs.php';

// Bump this to invalidate transients when prompt/output formatting rules change.
if ( ! defined('AG_LLM_CACHE_VERSION') ) {
    define('AG_LLM_CACHE_VERSION', '0.1.7');
}

register_activation_hook(__FILE__, 'ag_llm_queries_install');

/* =========================
 * i18n (Admin language override)
 * ========================= */

function summar_ai_load_textdomain() {
    $domain = 'summar-ai';

    // Admin override only on real admin screens (not AJAX).
    if ( is_admin() && function_exists('wp_doing_ajax') && wp_doing_ajax() ) {
        load_plugin_textdomain($domain, false, dirname(plugin_basename(__FILE__)) . '/languages');
        return;
    }

    if ( is_admin() ) {
        $pref = (string) get_option('summar_ai_admin_language', 'auto');

        if ( $pref === 'en_US' ) {
            // English = source strings (no translation loaded)
            return;
        }

        if ( $pref === 'tr_TR' ) {
            $mofile = trailingslashit(plugin_dir_path(__FILE__)) . 'languages/' . $domain . '-tr_TR.mo';
            if ( file_exists($mofile) ) {
                load_textdomain($domain, $mofile);
                return;
            }
            // If file missing, fall back to auto
        }

        // Auto (or fallback)
        load_plugin_textdomain($domain, false, dirname(plugin_basename(__FILE__)) . '/languages');
        return;
    }

    // Front-end: always follow site locale automatically
    load_plugin_textdomain($domain, false, dirname(plugin_basename(__FILE__)) . '/languages');
}
// WP i18n flow friendly timing (avoids JIT warnings)
add_action('init', 'summar_ai_load_textdomain', 1);

/* =========================
 * Assets
 * ========================= */

function ag_llm_register_assets() {
    wp_register_style(
        'ag-llm-search',
        plugins_url('assets/ag-llm-search.css', __FILE__),
        array(),
        '0.1.4'
    );

    wp_register_script(
        'summarai-frontend',
        plugins_url('assets/frontend.js', __FILE__),
        array(),
        '0.1.4',
        true
    );
}
add_action('wp_enqueue_scripts', 'ag_llm_register_assets', 5);

function ag_llm_enqueue_frontend_script() {
    if ( ! wp_script_is('summarai-frontend', 'registered') ) {
        ag_llm_register_assets();
    }
    if ( ! wp_script_is('summarai-frontend', 'enqueued') ) {
        wp_enqueue_script('summarai-frontend');
    }
    wp_localize_script('summarai-frontend', 'summaraiFrontend', array(
        'restUrl' => esc_url_raw( rest_url('summarai/v1/generate') ),
        'nonce' => wp_create_nonce('wp_rest'),
    ));
}

function ag_llm_maybe_enqueue_assets() {
    if ( is_admin() ) return;

    global $wp_query;
    if ( empty($wp_query) || empty($wp_query->posts) ) return;

    foreach ( (array) $wp_query->posts as $p ) {
        if ( $p instanceof WP_Post ) {
            if ( has_shortcode($p->post_content, 'summar-ai') || has_shortcode($p->post_content, 'ag_llm_test') ) {
                wp_enqueue_style('ag-llm-search');
                ag_llm_enqueue_frontend_script();
                break;
            }
        }
    }
}
add_action('wp_enqueue_scripts', 'ag_llm_maybe_enqueue_assets', 20);

/* =========================
 * Helpers
 * ========================= */

function ag_llm_get_api_key(): string {
    $opt = get_option('ag_openai_api_key');
    if ( ! empty($opt) ) return (string) $opt;
    return '';
}

function ag_llm_can_access_post( int $post_id ): bool {
    $post = get_post( $post_id );
    if ( ! $post ) return false;
    if ( post_password_required( $post ) ) return false;
    if ( $post->post_status === 'publish' ) return true;
    return is_user_logged_in() && current_user_can( 'read_post', $post_id );
}

function ag_llm_mb_lower( string $s ): string {
    return function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
}

/**
 * Enhanced sanitizer (removes meta references to "text/context", normalizes "not in text")
 */
function ag_llm_sanitize_answer_style( string $answer ): string {
    $a = trim((string)$answer);
    if ($a === '') return $a;

    // Normalize line endings
    $a = str_replace(array("\r\n", "\r"), "\n", $a);

    // Normalize "not found" message (TR)
    if ( preg_match('/^(Bu\s+bilgi\s+)?(bu\s+)?(yaz[ıi]|içerik|icerik|metin|makale)\s*(de|da)?\s*yok\.?$/iu', $a) ) {
        return 'Bu bilgi yazıda yok.';
    }

    // Normalize "not found" message (EN)
    if ( preg_match('/^(That|This)\s+information\s+is\s+not\s+in\s+the\s+(text|article|content)\.?$/i', $a) ) {
        return 'This information is not in the text.';
    }

    // Remove leading meta intros (TR)
    $a = preg_replace('/^\s*(Bu\s+(yaz[ıi]|içerik|icerik|makale|sayfa)|Aşağıdaki\s+(metin|içerik)|Verilen\s+(bağlam|metin|icerik|içerik))\s*[:,\-\–—]?\s*/iu', '', $a, 1);

    // Remove leading meta intros (EN)
    $a = preg_replace('/^\s*(In\s+the\s+(text|article|context)\s*,?\s*)/i', '', $a, 1);
    $a = preg_replace('/^\s*(According\s+to\s+the\s+(text|article)\s*,?\s*)/i', '', $a, 1);
    $a = preg_replace('/^\s*(Based\s+on\s+the\s+(text|article|context)\s*,?\s*)/i', '', $a, 1);

    // Remove meta adverbs/phrases inside sentences (TR)
    $a = preg_replace('/\b(bağlamda|yaz[ıi]da|metinde|içerikte|makalede)\b\s*/iu', '', $a);

    // Remove meta phrases inside sentences (EN)
    $a = preg_replace('/\b(in\s+the\s+(text|article|context)|according\s+to\s+the\s+(text|article)|based\s+on\s+the\s+(text|article|context))\b\s*/i', '', $a);

    // Reduce academic/meta phrasing (TR)
    $a = preg_replace('/\b(bahsetmektedir|anlatmaktadır|ele\s+almaktadır)\b/iu', 'anlatır', $a);

    // If the model returned a single paragraph with multiple " - " segments,
    // convert it into: intro paragraph + bullet list + optional closing paragraph.
    if ( strpos($a, "\n") === false ) {
        $parts = preg_split('/\s+[-–—]\s+/u', $a);
        if ( is_array($parts) && count($parts) >= 3 ) {
            $intro = trim((string) array_shift($parts));
            $tail  = trim((string) end($parts));

            $closing = '';
            if ( $tail !== '' && preg_match('/^(Sonu(c|ç)|Özetle|Kısacası|Genel\s+olarak|Bu\s+nedenle|Bu\s+yüzden|Dolayısıyla|Son\s+olarak|Soğuk\s+iklimlerde)\b/iu', $tail) ) {
                $closing = array_pop($parts);
                $closing = trim((string) $closing);
            }

            if ( $intro !== '' ) {
                if ( ! preg_match('/[\.\!\?]\s*$/u', $intro) ) $intro .= '.';
            }

            $bullets = array();
            foreach ( $parts as $p ) {
                $p = trim((string) $p);
                if ( $p === '' ) continue;
                if ( ! preg_match('/[\.\!\?]\s*$/u', $p) ) $p .= '.';
                $bullets[] = $p;
            }

            if ( count($bullets) >= 2 ) {
                $out = $intro;
                $out .= "\n\n";
                foreach ( $bullets as $b ) {
                    $out .= "* {$b}\n";
                }
                $out = rtrim($out, "\n");

                if ( $closing !== '' ) {
                    if ( ! preg_match('/[\.\!\?]\s*$/u', $closing) ) $closing .= '.';
                    $out .= "\n\n" . $closing;
                }

                $a = $out;
            }
        }
    }

    // Normalize line-start bullets to "* "
    $a = preg_replace('/^[\t ]*[\-•\*]\s+/mu', '* ', $a);

    // Cleanup whitespace without destroying newlines
    $a = preg_replace('/[ \t]{2,}/u', ' ', $a);
    $a = preg_replace('/[ \t]+\n/u', "\n", $a);
    $a = preg_replace('/\n[ \t]+/u', "\n", $a);
    $a = preg_replace("/\n{3,}/", "\n\n", $a);

    return trim($a);
}

/* =========================
 * Context
 * ========================= */

function ag_llm_build_context_from_post( int $post_id, int $max_chars = 12000 ): string {
    $post = get_post( $post_id );
    if ( ! $post ) return '';

    $content = (string) $post->post_content;
    $title   = get_the_title( $post );

    $content = strip_shortcodes( $content );
    $content = wp_strip_all_tags( $content, true );
    $content = preg_replace('/```[\s\S]*?```/u', ' ', $content);
    $content = preg_replace('/\s+/u', ' ', $content);
    $content = trim($content);

    if ( function_exists('mb_strlen') && function_exists('mb_substr') ) {
        if ( mb_strlen($content, 'UTF-8') > $max_chars ) {
            $content = mb_substr($content, 0, $max_chars, 'UTF-8') . ' …';
        }
    } else {
        if ( strlen($content) > $max_chars ) {
            $content = substr($content, 0, $max_chars) . ' …';
        }
    }

    return "TITLE:\n{$title}\n\nTEXT:\n{$content}";
}

/* =========================
 * LLM
 * ========================= */

function ag_llm_query_article( string $question, int $post_id ) {
    $api_key = ag_llm_get_api_key();
    if ( empty($api_key) ) {
        return new WP_Error('ag_llm_no_key', 'OpenAI API anahtarı bulunamadı.');
    }

    $context = ag_llm_build_context_from_post($post_id);
    if ( empty($context) ) {
        return new WP_Error('ag_llm_no_context', 'Yazı bağlamı üretilemedi.');
    }

$system_prompt = "You are a Q&A assistant. Answer using ONLY the provided reference text.

Hard constraints:
- Do NOT mention the text/article/context/source (e.g., 'in the text', 'according to the article', 'based on the context', TR: 'bağlamda', 'yazıda', 'metinde', 'içerikte', 'makalede'). Speak directly to the user.
- Never invent facts or add outside knowledge. If the needed information is not present, respond with exactly:
  - Turkish: 'Bu bilgi yazıda yok.'
  - English: 'This information is not in the text.'
- Answer in the same language as the user's question.

Answer quality:
- Start with a clear stance that fits the question (avoid absolute yes/no unless the reference text is absolute).
- Then justify with 2–5 concrete points that are explicitly supported by the reference text.
- Keep paragraphs short (1–2 sentences).

Output format (strict):
- Do NOT add section titles/headings (e.g., 'Why needed?', 'Neden gerekli?') unless the user explicitly asks for headings.
- If a list improves clarity, you MUST use ONLY this format:
  1) Write the lead-in sentence as a normal sentence and end it with a period.
  2) Add a blank line.
  3) Each bullet must be on its own line and MUST start at the beginning of the line with '* ' (asterisk + space).
  4) (Optional) If you add a concluding sentence, put it AFTER the list, separated by a blank line.
- Never write inline bullets or dash-separated list items in a paragraph.
  Forbidden patterns: ': - item', '. - item - item', 'because: -', 'çünkü: -', ' - item - item'.
- Do NOT use other bullet symbols ('•', '-') and do NOT use numbered lists.";

    $user_prompt = "REFERENCE:\n{$context}\n\nQUESTION:\n{$question}\n\nAnswer.";

    // Settings (admin)
    $model_opt = (string) get_option('ag_llm_model');
    $model_default = ! empty($model_opt) ? $model_opt : 'gpt-4.1-nano';

    $temp_opt = get_option('ag_llm_temperature');
    $temperature_default = (is_numeric($temp_opt)) ? (float) $temp_opt : 0.2;

    $max_tokens_opt = get_option('ag_llm_max_tokens');
    $max_tokens_default = (is_numeric($max_tokens_opt) && (int) $max_tokens_opt > 0) ? (int) $max_tokens_opt : 420;

    $body = array(
        'model' => apply_filters('ag_llm_model', $model_default, $post_id),
        'messages' => array(
            array('role' => 'system', 'content' => $system_prompt),
            array('role' => 'user',   'content' => $user_prompt),
        ),
        'temperature' => $temperature_default,
        'max_tokens'  => $max_tokens_default,
    );

    $result = summarai_openai_request( $body );
    if ( empty( $result['ok'] ) ) {
        $message = isset( $result['error'] ) ? (string) $result['error'] : 'LLM request failed.';
        return new WP_Error('ag_llm_request_failed', $message);
    }

    $data = $result['data'];
    if ( ! $data || empty( $data['choices'][0]['message']['content'] ) ) {
        return new WP_Error('ag_llm_bad_payload', 'LLM yanıtı beklenen formatta değil.');
    }

    $answer = trim( (string) $data['choices'][0]['message']['content'] );
    return ag_llm_sanitize_answer_style($answer);
}

/* =========================
 * REST API
 * ========================= */

function summarai_rest_can_generate(): bool {
    return true;
}

function summarai_rest_generate( WP_REST_Request $request ) {
    $params = $request->get_json_params();
    $prompt = '';
    $post_id = 0;
    if ( is_array($params) && isset($params['prompt']) ) {
        $prompt = sanitize_textarea_field( (string) $params['prompt'] );
    }
    if ( is_array($params) && isset($params['post_id']) ) {
        $post_id = (int) $params['post_id'];
    }

    if ( $post_id <= 0 || $prompt === '' ) {
        return rest_ensure_response(array(
            'ok' => false,
            'error' => 'Prompt and post ID are required.',
        ));
    }

    $max_q_len = (int) apply_filters('ag_llm_max_question_chars', 300);
    if ( function_exists('mb_strlen') ? (mb_strlen($prompt, 'UTF-8') > $max_q_len) : (strlen($prompt) > $max_q_len) ) {
        return rest_ensure_response(array(
            'ok' => false,
            'error' => 'Soru çok uzun. Lütfen daha kısa yaz.',
        ));
    }

    if ( ! ag_llm_can_access_post( $post_id ) ) {
        return rest_ensure_response(array(
            'ok' => false,
            'error' => 'Bu içerik için erişim yok.',
        ));
    }

    // Rate limit: empty => default 6, 0 disables
    $rl_opt = get_option('ag_llm_rate_limit_per_minute', '');
    $limit_default = ($rl_opt === '' || $rl_opt === null) ? 6 : (int) $rl_opt;
    $limit = (int) apply_filters('ag_llm_rate_limit_per_minute', $limit_default, $post_id);

    if ( $limit > 0 && ag_llm_rate_limit_hit($post_id, $limit) ) {
        return rest_ensure_response(array(
            'ok' => false,
            'error' => 'Çok fazla istek. Lütfen biraz sonra tekrar dene.',
        ));
    }

    $modified = (string) get_post_modified_time('U', true, $post_id);
    $q_norm   = ag_llm_mb_lower(trim($prompt));
    $q_norm   = preg_replace('/\s+/u', ' ', $q_norm);
    $q_hash   = substr( md5($q_norm), 0, 16 );
    $model_opt = (string) get_option('ag_llm_model');
    $model_default = ! empty($model_opt) ? $model_opt : 'gpt-4.1-nano';
    $model = apply_filters('ag_llm_model', $model_default, $post_id);
    $model_hash = substr(md5((string) $model), 0, 10);
    $cache_key = 'ag_llm_' . $post_id . '_' . $modified . '_' . AG_LLM_CACHE_VERSION . '_' . $model_hash . '_' . $q_hash;

    // Cache TTL: empty => 6 hours, 0 disables
    $ttl_opt = get_option('ag_llm_cache_ttl_seconds', '');
    $ttl_default = ($ttl_opt === '' || $ttl_opt === null) ? (6 * HOUR_IN_SECONDS) : (int) $ttl_opt;
    $ttl = (int) apply_filters('ag_llm_cache_ttl_seconds', $ttl_default, $post_id);

    if ( $ttl > 0 ) {
        $cached = get_transient($cache_key);
        if ( is_string($cached) && $cached !== '' ) {
            // Log successful cache hits for REST responses.
            ag_llm_log_query($post_id, $prompt, $cached, (string) $model);
            return rest_ensure_response(array(
                'ok' => true,
                'answer' => $cached,
                'from_cache' => true,
            ));
        }
    }

    $res = ag_llm_query_article( $prompt, $post_id );

    if ( is_wp_error($res) ) {
        $code = $res->get_error_code();
        $msg = ($code === 'ag_llm_quota')
            ? 'Şu anda LLM servisi kota nedeniyle yanıt veremiyor. Lütfen daha sonra tekrar deneyin.'
            : 'İstek şu anda tamamlanamadı. Lütfen tekrar deneyin.';
        return rest_ensure_response(array(
            'ok' => false,
            'error' => $msg,
        ));
    }

    if ( $ttl > 0 ) {
        set_transient($cache_key, $res, $ttl);
    }

    // Log successful REST responses from the LLM.
    ag_llm_log_query($post_id, $prompt, $res, (string) $model);
    return rest_ensure_response(array(
        'ok' => true,
        'answer' => $res,
        'from_cache' => false,
    ));
}

function summarai_register_rest_routes() {
    register_rest_route('summarai/v1', '/generate', array(
        'methods' => 'POST',
        'callback' => 'summarai_rest_generate',
        'permission_callback' => 'summarai_rest_can_generate',
    ));
}
add_action('rest_api_init', 'summarai_register_rest_routes');

/* =========================
 * AJAX
 * ========================= */

add_action('wp_ajax_ag_llm_search', 'ag_llm_ajax_search');
add_action('wp_ajax_nopriv_ag_llm_search', 'ag_llm_ajax_search');
add_action('wp_ajax_ag_llm_get_nonce', 'ag_llm_ajax_get_nonce');
add_action('wp_ajax_nopriv_ag_llm_get_nonce', 'ag_llm_ajax_get_nonce');

function ag_llm_ajax_get_nonce() {
    nocache_headers();

    if ( $_SERVER['REQUEST_METHOD'] !== 'POST' ) {
        wp_send_json_error(array('message' => 'Method not allowed.'), 405);
    }

    $ref = wp_get_referer();
    if ( $ref ) {
        $ref_host  = (string) parse_url($ref, PHP_URL_HOST);
        $home_host = (string) parse_url(home_url('/'), PHP_URL_HOST);
        if ( $ref_host && $home_host && strtolower($ref_host) !== strtolower($home_host) ) {
            wp_send_json_error(array('message' => 'Invalid origin.'), 403);
        }
    }

    $nonce = wp_create_nonce('ag_llm_nonce');
    wp_send_json_success(array('nonce' => $nonce));
}

function ag_llm_rate_limit_hit( int $post_id, int $limit_per_minute = 6 ): bool {
    $ip = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
    $ip_hash = substr( md5($ip), 0, 12 );
    $key = 'ag_llm_rl_' . $post_id . '_' . $ip_hash;

    $count = (int) get_transient($key);
    $count++;
    set_transient($key, $count, 60);

    return $count > $limit_per_minute;
}

function ag_llm_ajax_search() {
    nocache_headers();

    $nonce = isset($_POST['nonce']) ? sanitize_text_field( wp_unslash($_POST['nonce']) ) : '';
    if ( ! wp_verify_nonce($nonce, 'ag_llm_nonce') ) {
        wp_send_json_error(array('message' => 'Geçersiz istek (nonce).'), 403);
    }

    $post_id = isset($_POST['post_id']) ? (int) $_POST['post_id'] : 0;
    $q       = isset($_POST['q']) ? sanitize_text_field( wp_unslash($_POST['q']) ) : '';

    if ( $post_id <= 0 || $q === '' ) {
        wp_send_json_error(array('message' => 'Eksik parametre.'), 400);
    }

    $max_q_len = (int) apply_filters('ag_llm_max_question_chars', 300);
    if ( function_exists('mb_strlen') ? (mb_strlen($q, 'UTF-8') > $max_q_len) : (strlen($q) > $max_q_len) ) {
        wp_send_json_error(array('message' => 'Soru çok uzun. Lütfen daha kısa yaz.'), 400);
    }

    if ( ! ag_llm_can_access_post( $post_id ) ) {
        wp_send_json_error(array('message' => 'Bu içerik için erişim yok.'), 403);
    }

    // Rate limit: empty => default 6, 0 disables
    $rl_opt = get_option('ag_llm_rate_limit_per_minute', '');
    $limit_default = ($rl_opt === '' || $rl_opt === null) ? 6 : (int) $rl_opt;
    $limit = (int) apply_filters('ag_llm_rate_limit_per_minute', $limit_default, $post_id);

    if ( $limit > 0 && ag_llm_rate_limit_hit($post_id, $limit) ) {
        wp_send_json_error(array('message' => 'Çok fazla istek. Lütfen biraz sonra tekrar dene.'), 429);
    }

    $model_opt = (string) get_option('ag_llm_model');
    $model_default = ! empty($model_opt) ? $model_opt : 'gpt-4.1-nano';
    $model = apply_filters('ag_llm_model', $model_default, $post_id);

    $modified = (string) get_post_modified_time('U', true, $post_id);
    $q_norm   = ag_llm_mb_lower(trim($q));
    $q_norm   = preg_replace('/\s+/u', ' ', $q_norm);
    $q_hash   = substr( md5($q_norm), 0, 16 );
    $model_hash = substr(md5((string) $model), 0, 10);
    $cache_key = 'ag_llm_' . $post_id . '_' . $modified . '_' . AG_LLM_CACHE_VERSION . '_' . $model_hash . '_' . $q_hash;

    // Cache TTL: empty => 6 hours, 0 disables
    $ttl_opt = get_option('ag_llm_cache_ttl_seconds', '');
    $ttl_default = ($ttl_opt === '' || $ttl_opt === null) ? (6 * HOUR_IN_SECONDS) : (int) $ttl_opt;
    $ttl = (int) apply_filters('ag_llm_cache_ttl_seconds', $ttl_default, $post_id);

    if ( $ttl > 0 ) {
        $cached = get_transient($cache_key);
        if ( is_string($cached) && $cached !== '' ) {
            ag_llm_log_query($post_id, $q, $cached, (string) $model);
            wp_send_json_success(array('answer' => $cached, 'from_cache' => true));
        }
    }

    $res = ag_llm_query_article( $q, $post_id );

    if ( is_wp_error($res) ) {
        $code = $res->get_error_code();
        $msg = ($code === 'ag_llm_quota')
            ? 'Şu anda LLM servisi kota nedeniyle yanıt veremiyor. Lütfen daha sonra tekrar deneyin.'
            : 'İstek şu anda tamamlanamadı. Lütfen tekrar deneyin.';
        wp_send_json_error(array('message' => $msg), 200);
    }

    if ( $ttl > 0 ) set_transient($cache_key, $res, $ttl);

    ag_llm_log_query($post_id, $q, $res, (string) $model);
    wp_send_json_success(array('answer' => $res, 'from_cache' => false));
}

/* =========================
 * Shortcode UI
 * ========================= */

function ag_llm_search_box_shortcode(): string {
    $post_id = (int) get_the_ID();
    if ( ! $post_id ) return '';

    if ( ! wp_style_is('ag-llm-search', 'registered') ) ag_llm_register_assets();
    if ( ! wp_style_is('ag-llm-search', 'enqueued') ) wp_enqueue_style('ag-llm-search');
    ag_llm_enqueue_frontend_script();
    if ( did_action('wp_head') ) wp_print_styles('ag-llm-search');

    $grad_id = 'agStarsGrad_' . $post_id . '_' . wp_rand(1000,9999);

    ob_start(); ?>

<div class="ag-llm-search" data-post-id="<?php echo esc_attr($post_id); ?>">
  <div class="ag-llm-shell" role="group" aria-label="Yazı içi arama">
    <div class="ag-llm-inner">

      <div class="ag-llm-prefix" aria-hidden="true">
        <span class="ag-llm-stars">
          <svg viewBox="0 0 34 30" xmlns="http://www.w3.org/2000/svg" fill="none" aria-hidden="true">
            <defs>
              <linearGradient id="<?php echo esc_attr($grad_id); ?>" x1="6" y1="2" x2="30" y2="28" gradientUnits="userSpaceOnUse">
                <stop stop-color="#FFD45A"/>
                <stop offset="1" stop-color="#FF8A00"/>
              </linearGradient>
            </defs>

            <path d="M 4.7 -0.5 L 6.2 3.3 L 10.0 4.8 L 6.2 6.3 L 4.7 10.1 L 3.2 6.3 L -0.6 4.8 L 3.2 3.3 Z"
                  fill="#FFD45A" opacity=".95"/>

            <path d="M 15.5 1.3 L 19.7 10.8 L 29.8 15.0 L 19.7 19.2 L 15.5 28.6 L 11.3 19.2 L 1.2 15.0 L 11.3 10.8 Z"
                  fill="url(#<?php echo esc_attr($grad_id); ?>)"/>

            <path d="M 29.9 18.7 L 31.4 22.5 L 35.2 24.0 L 31.4 25.5 L 29.9 29.3 L 28.4 25.5 L 24.6 24.0 L 28.4 22.5 Z"
                  fill="#FF8A00" opacity=".92"/>
          </svg>
        </span>
      </div>

      <input class="ag-llm-input" type="text" placeholder="Yazıda AI ile bul" autocomplete="off">
    </div>

    <button class="ag-llm-btn" type="button" aria-label="Gönder">
      <span class="ag-llm-btn-icon" aria-hidden="true">
        <svg viewBox="0 0 24 24" fill="none">
          <path d="M5 12h12" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>
          <path d="M13 6l6 6-6 6" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </span>
      <span class="ag-llm-spinner" aria-hidden="true"></span>
    </button>
  </div>

  <div class="ag-llm-status" role="status" aria-live="polite"></div>
  <div class="ag-llm-result" role="region" aria-live="polite"></div>
</div>

<?php
    return (string) ob_get_clean();
}
add_shortcode('summar-ai', 'ag_llm_search_box_shortcode');

/* =========================
 * Admin Panel (Settings)
 * ========================= */

function ag_llm_admin_menu() {
    add_options_page(
        __('Summar AI', 'summar-ai'),
        __('Summar AI', 'summar-ai'),
        'manage_options',
        'ag-llm-settings',
        'ag_llm_render_settings_page'
    );
}
add_action('admin_menu', 'ag_llm_admin_menu');

function ag_llm_plugin_action_links( $links ) {
    $url = admin_url('options-general.php?page=ag-llm-settings');
    $links[] = '<a href="' . esc_url($url) . '">' . esc_html__('Settings', 'summar-ai') . '</a>';
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'ag_llm_plugin_action_links');

function ag_llm_sanitize_api_key( $v ) {
    $v = is_string($v) ? trim($v) : '';
    if ( $v === '' ) {
        $should_clear = ! empty($_POST['ag_llm_clear_api_key']);
        if ( $should_clear ) {
            return '';
        }

        $existing = (string) get_option('ag_openai_api_key');
        return $existing;
    }

    return $v;
}

function ag_llm_sanitize_model( $v ) {
    $v = is_string($v) ? trim($v) : '';
    return $v;
}

function ag_llm_sanitize_temperature( $v ) {
    if ( $v === '' || $v === null ) return '';
    if ( ! is_numeric($v) ) return '';
    $f = (float) $v;
    if ( $f < 0 ) $f = 0;
    if ( $f > 2 ) $f = 2;
    return (string) $f;
}

function ag_llm_sanitize_int( $v ) {
    if ( $v === '' || $v === null ) return '';
    $i = is_numeric($v) ? (int) $v : 0;
    if ( $i < 0 ) $i = 0;
    return (string) $i;
}

function ag_llm_sanitize_cache_ttl_hours( $hours ) {
    if ( $hours === '' || $hours === null ) return '';
    if ( ! is_numeric($hours) ) return '';
    $h = (float) $hours;
    if ( $h < 0 ) $h = 0;
    // hours -> seconds
    $sec = (int) round($h * HOUR_IN_SECONDS);
    return (string) $sec;
}

function summar_ai_sanitize_admin_language( $v ) {
    $v = is_string($v) ? trim($v) : '';
    $allowed = array('auto', 'tr_TR', 'en_US');
    if ( ! in_array($v, $allowed, true) ) return 'auto';
    return $v;
}

function ag_llm_register_settings() {
    register_setting('ag_llm_settings', 'ag_openai_api_key', array(
        'type' => 'string',
        'sanitize_callback' => 'ag_llm_sanitize_api_key',
        'default' => '',
    ));

    register_setting('ag_llm_settings', 'ag_llm_model', array(
        'type' => 'string',
        'sanitize_callback' => 'ag_llm_sanitize_model',
        'default' => '',
    ));

    register_setting('ag_llm_settings', 'ag_llm_temperature', array(
        'type' => 'string',
        'sanitize_callback' => 'ag_llm_sanitize_temperature',
        'default' => '',
    ));

    register_setting('ag_llm_settings', 'ag_llm_max_tokens', array(
        'type' => 'string',
        'sanitize_callback' => 'ag_llm_sanitize_int',
        'default' => '',
    ));

    // stored as seconds (ag_llm_cache_ttl_seconds); input is hours
    register_setting('ag_llm_settings', 'ag_llm_cache_ttl_seconds', array(
        'type' => 'string',
        'sanitize_callback' => 'ag_llm_sanitize_cache_ttl_hours',
        'default' => '',
    ));

    register_setting('ag_llm_settings', 'ag_llm_rate_limit_per_minute', array(
        'type' => 'string',
        'sanitize_callback' => 'ag_llm_sanitize_int',
        'default' => '',
    ));

    register_setting('ag_llm_settings', 'summar_ai_admin_language', array(
        'type' => 'string',
        'sanitize_callback' => 'summar_ai_sanitize_admin_language',
        'default' => 'auto',
    ));
}
add_action('admin_init', 'ag_llm_register_settings');

function ag_llm_admin_notices() {
    if ( ! current_user_can('manage_options') ) return;

    // WP core "settings-updated"
    if ( isset($_GET['settings-updated']) && $_GET['settings-updated'] === 'true' && isset($_GET['page']) && $_GET['page'] === 'ag-llm-settings' ) {
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Settings saved.', 'summar-ai') . '</p></div>';
        return;
    }

    if ( empty($_GET['ag_llm_notice']) ) return;

    $notice = sanitize_text_field( (string) $_GET['ag_llm_notice'] );
    $type   = (! empty($_GET['ag_llm_type']) && $_GET['ag_llm_type'] === 'error') ? 'error' : 'success';
    $msg    = '';

    if ( $notice === 'cache_cleared' ) $msg = __('Cache cleared.', 'summar-ai');
    if ( $notice === 'cache_clear_fail' ) $msg = __('Cache could not be cleared. (See PHP error log for details.)', 'summar-ai');

    if ( ! $msg ) return;

    echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible"><p>' . esc_html($msg) . '</p></div>';
}
add_action('admin_notices', 'ag_llm_admin_notices');

function ag_llm_render_settings_page() {
    if ( ! current_user_can('manage_options') ) return;

    $tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'settings';

    $api_key = (string) get_option('ag_openai_api_key');
    $model   = (string) get_option('ag_llm_model');
    $temp    = (string) get_option('ag_llm_temperature');
    $max_t   = (string) get_option('ag_llm_max_tokens');

    $ttl_raw = get_option('ag_llm_cache_ttl_seconds', '');
    $ttl_sec = ($ttl_raw === '' || $ttl_raw === null) ? '' : (int) $ttl_raw;
    $ttl_hours = ($ttl_sec !== '' && $ttl_sec >= 0) ? ($ttl_sec / HOUR_IN_SECONDS) : '';

    $rl = (string) get_option('ag_llm_rate_limit_per_minute');
    $admin_lang = (string) get_option('summar_ai_admin_language', 'auto');
    ?>
    <div class="wrap">
      <h1><?php echo esc_html__('Summar AI', 'summar-ai'); ?></h1>
      <?php ag_llm_render_settings_tabs($tab); ?>
      <?php if ( $tab === 'logs' ) { ag_llm_render_logs_tab(); return; } ?>
      <p><?php echo esc_html__('Manage your API key and core settings here.', 'summar-ai'); ?></p>

      <form method="post" action="options.php">
        <?php settings_fields('ag_llm_settings'); ?>

        <table class="form-table" role="presentation">
          <tr>
            <th scope="row"><label for="ag_openai_api_key"><?php echo esc_html__('OpenAI API Key', 'summar-ai'); ?></label></th>
            <td>
              <input type="password" id="ag_openai_api_key" name="ag_openai_api_key" value="" class="regular-text" autocomplete="new-password" />
              <p class="description">
                <?php echo esc_html__('Enter a new API key. Leave blank to keep the saved key.', 'summar-ai'); ?>
                <?php if ( ! empty($api_key) ) : ?>
                  <?php echo esc_html__('(A key is currently saved.)', 'summar-ai'); ?>
                <?php endif; ?>
              </p>
              <label>
                <input type="checkbox" name="ag_llm_clear_api_key" value="1" />
                <?php echo esc_html__('Clear saved API key', 'summar-ai'); ?>
              </label>
            </td>
          </tr>

          <tr>
            <th scope="row"><label for="ag_llm_model"><?php echo esc_html__('Model', 'summar-ai'); ?></label></th>
            <td>
              <input type="text" id="ag_llm_model" name="ag_llm_model" value="<?php echo esc_attr($model); ?>" class="regular-text" placeholder="gpt-4.1-nano" />
              <p class="description"><?php echo esc_html__('Default if empty:', 'summar-ai'); ?> <code>gpt-4.1-nano</code>.</p>
            </td>
          </tr>

          <tr>
            <th scope="row"><label for="ag_llm_temperature"><?php echo esc_html__('Temperature', 'summar-ai'); ?></label></th>
            <td>
              <input type="number" step="0.1" min="0" max="2" id="ag_llm_temperature" name="ag_llm_temperature" value="<?php echo esc_attr($temp); ?>" class="small-text" placeholder="0.2" />
              <p class="description"><?php echo esc_html__('Default if empty:', 'summar-ai'); ?> <code>0.2</code>.</p>
            </td>
          </tr>

          <tr>
            <th scope="row"><label for="ag_llm_max_tokens"><?php echo esc_html__('Max tokens', 'summar-ai'); ?></label></th>
            <td>
              <input type="number" min="1" id="ag_llm_max_tokens" name="ag_llm_max_tokens" value="<?php echo esc_attr($max_t); ?>" class="small-text" placeholder="420" />
              <p class="description"><?php echo esc_html__('Default if empty:', 'summar-ai'); ?> <code>420</code>.</p>
            </td>
          </tr>

          <tr>
            <th scope="row"><label for="ag_llm_cache_ttl_seconds"><?php echo esc_html__('Cache TTL (hours)', 'summar-ai'); ?></label></th>
            <td>
              <input type="number" step="0.5" min="0" id="ag_llm_cache_ttl_seconds" name="ag_llm_cache_ttl_seconds" value="<?php echo esc_attr($ttl_hours); ?>" class="small-text" placeholder="6" />
              <p class="description"><?php echo esc_html__('Set to 0 to disable cache. Default if empty: 6 hours.', 'summar-ai'); ?></p>
            </td>
          </tr>

          <tr>
            <th scope="row"><label for="ag_llm_rate_limit_per_minute"><?php echo esc_html__('Rate limit (per minute)', 'summar-ai'); ?></label></th>
            <td>
              <input type="number" min="0" id="ag_llm_rate_limit_per_minute" name="ag_llm_rate_limit_per_minute" value="<?php echo esc_attr($rl); ?>" class="small-text" placeholder="6" />
              <p class="description"><?php echo esc_html__('Set to 0 to disable rate limiting. Default if empty: 6.', 'summar-ai'); ?></p>
            </td>
          </tr>

          <tr>
            <th scope="row"><label for="summar_ai_admin_language"><?php echo esc_html__('Language', 'summar-ai'); ?></label></th>
            <td>
              <select id="summar_ai_admin_language" name="summar_ai_admin_language">
                <option value="auto" <?php selected($admin_lang, 'auto'); ?>><?php echo esc_html__('Auto (follow WordPress admin language)', 'summar-ai'); ?></option>
                <option value="en_US" <?php selected($admin_lang, 'en_US'); ?>><?php echo esc_html__('English', 'summar-ai'); ?></option>
                <option value="tr_TR" <?php selected($admin_lang, 'tr_TR'); ?>><?php echo esc_html__('Turkish', 'summar-ai'); ?></option>
              </select>
              <p class="description">
                <?php echo wp_kses_post( __( 'Auto uses the WordPress admin language. Turkish requires a <code>summar-ai-tr_TR.mo</code> file in <code>/languages</code>.', 'summar-ai' ) ); ?>
              </p>
            </td>
          </tr>
        </table>

        <?php submit_button( __('Save Changes', 'summar-ai') ); ?>
      </form>

      <hr />

      <h2><?php echo esc_html__('Quick Actions', 'summar-ai'); ?></h2>

      <div style="display:flex; gap:16px; align-items:flex-start; flex-wrap:wrap;">
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
          <?php wp_nonce_field('ag_llm_clear_cache'); ?>
          <input type="hidden" name="action" value="ag_llm_clear_cache" />
          <?php submit_button( __('Clear Cache', 'summar-ai'), 'delete', 'submit', false ); ?>
          <p class="description" style="margin-top:8px;"><?php echo esc_html__('Clears this plugin’s transient cache and rate-limit records.', 'summar-ai'); ?></p>
        </form>
      </div>

      <hr />

      <h2><?php echo esc_html__('Usage', 'summar-ai'); ?></h2>
      <p><?php echo esc_html__('Add this shortcode to any post/page:', 'summar-ai'); ?></p>
      <p><code>[summar-ai]</code></p>
    </div>
    <?php
}

/**
 * Admin action: Clear Cache (transients)
 * Fix: LIKE patterns must escape '_' (underscore is a wildcard in SQL LIKE).
 */
function ag_llm_handle_admin_clear_cache() {
    if ( ! current_user_can('manage_options') ) wp_die( esc_html__('Unauthorized.', 'summar-ai') );
    check_admin_referer('ag_llm_clear_cache');

    global $wpdb;
    try {
        $prefixes = array(
            '_transient_ag_llm_',
            '_transient_timeout_ag_llm_',
            '_transient_ag_llm_rl_',
            '_transient_timeout_ag_llm_rl_',
        );

        foreach ( $prefixes as $prefix ) {
            $like = $wpdb->esc_like($prefix) . '%';
            $sql  = "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s ESCAPE '\\\\'";
            $wpdb->query( $wpdb->prepare($sql, $like) );
        }

        $url = add_query_arg(array('page' => 'ag-llm-settings', 'ag_llm_notice' => 'cache_cleared'), admin_url('options-general.php'));
        wp_safe_redirect($url);
        exit;
    } catch (Throwable $e) {
        error_log('[Summar AI] Cache clear failed: ' . $e->getMessage());
        $url = add_query_arg(array('page' => 'ag-llm-settings', 'ag_llm_notice' => 'cache_clear_fail', 'ag_llm_type' => 'error'), admin_url('options-general.php'));
        wp_safe_redirect($url);
        exit;
    }
}
add_action('admin_post_ag_llm_clear_cache', 'ag_llm_handle_admin_clear_cache');
