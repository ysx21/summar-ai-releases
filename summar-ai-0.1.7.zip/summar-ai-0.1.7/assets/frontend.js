(function(){
  function initWidget(wrap){
    if (!wrap || wrap.dataset && wrap.dataset.summaraiInit) return;
    if (wrap.dataset) wrap.dataset.summaraiInit = '1';

    var shell  = wrap.querySelector('.ag-llm-shell');
    var input  = wrap.querySelector('.ag-llm-input');
    var btn    = wrap.querySelector('.ag-llm-btn');
    var status = wrap.querySelector('.ag-llm-status');
    var out    = wrap.querySelector('.ag-llm-result');

    if (!shell || !input || !btn || !status || !out) return;

    shell.addEventListener('click', function(e){
      var t = e.target;
      if (t && t.closest && t.closest('.ag-llm-btn')) return;
      input && input.focus();
    });
    setTimeout(function(){ input && input.focus(); }, 220);

    function setLoading(isLoading){
      wrap.classList.toggle('is-loading', !!isLoading);
      btn.disabled = !!isLoading;
      btn.setAttribute('aria-busy', isLoading ? 'true' : 'false');
    }
    function setStatus(text){
      status.textContent = text || '';
      wrap.classList.toggle('has-status', !!text);
    }
    function escapeHtml(s){
      return String(s || '')
        .replace(/&/g,'&amp;')
        .replace(/</g,'&lt;')
        .replace(/>/g,'&gt;')
        .replace(/"/g,'&quot;')
        .replace(/'/g,'&#039;');
    }
    function capFirst(s){
      s = String(s || '').trim();
      if (!s) return s;
      return s.charAt(0).toUpperCase() + s.slice(1);
    }
    function isLikelyQuestion(q){
      var s = String(q || '').trim().toLowerCase();
      if (!s) return false;
      if (s.indexOf('?') !== -1) return true;
      if (/^(ne|neden|nasıl|nasil|kim|kaç|kac|hangi|nerede|nereye|nerden|nereden|ne zaman)\b/.test(s)) return true;
      if (/\b(mı|mi|mu|mü)\b/.test(s)) return true;
      if (/(mı|mi|mu|mü)$/.test(s)) return true;
      return false;
    }
    function normalizeQuestionForDisplay(q){
      var s = capFirst(q);
      if (!s) return s;
      var hasQM = /\?\s*$/.test(s);
      if (!hasQM && isLikelyQuestion(q)) s = s.replace(/\s+$/,'') + '?';
      return s;
    }

    function formatAnswer(raw){
      var text = String(raw || '').trim();
      if (!text) return { html: '' };

      if (/\n|•|\-\s|\*\s/.test(text)) {
        text = text.replace(/\n{3,}/g, "\n\n");
        var lines = text.split(/\n/);
        var htmlParts = [];
        var list = [];

        function flushList(){
          if (list.length){
            htmlParts.push('<ul>' + list.map(function(li){
              return '<li>' + escapeHtml(li.replace(/^(\-|\*|•)\s*/,'').trim()) + '</li>';
            }).join('') + '</ul>');
            list = [];
          }
        }

        lines.forEach(function(line){
          var l = line.trim();
          if (!l) { flushList(); return; }
          if (/^(\-|\*|•)\s+/.test(l)) { list.push(l); return; }
          flushList();
          htmlParts.push('<p>' + escapeHtml(l) + '</p>');
        });

        flushList();
        return { html: htmlParts.join('') };
      }

      var sentences = text.split(/(?<=[\.\!\?])\s+/).filter(Boolean);
      var paras = [];
      for (var i=0; i<sentences.length; i+=2){
        var chunk = sentences.slice(i, i+2).join(' ');
        paras.push('<p>' + escapeHtml(chunk.trim()) + '</p>');
      }
      return { html: paras.join('') };
    }

    function setResult(question, answer){
      var qDisp = normalizeQuestionForDisplay(question);
      var formatted = formatAnswer(answer);
      out.innerHTML =
        '<div class="ag-llm-q"><strong>' + escapeHtml(qDisp) + '</strong></div>' +
        '<div class="ag-llm-a">' + (formatted.html || '') + '</div>';
      wrap.classList.toggle('has-result', true);
    }
    function clearResult(){
      out.innerHTML = '';
      wrap.classList.toggle('has-result', false);
    }

    function request(q){
      var config = window.summaraiFrontend || {};
      var postId = wrap.dataset ? parseInt(wrap.dataset.postId, 10) : 0;
      if (!config.restUrl || !config.nonce) {
        setResult(q, 'İstek yapılamadı.');
        return;
      }
      if (!postId) {
        setResult(q, 'İstek yapılamadı.');
        return;
      }

      setLoading(true);
      setStatus('Yükleniyor…');
      clearResult();
      input.value = '';

      fetch(config.restUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': config.nonce
        },
        body: JSON.stringify({ prompt: q, post_id: postId }),
        credentials: 'same-origin'
      })
        .then(function(r){ return r.json(); })
        .then(function(json){
          setStatus('');
          if (!json) { setResult(q, 'Beklenmeyen sonuç.'); return; }
          if (json.ok) {
            setResult(q, json.answer || '');
            return;
          }
          setResult(q, json.error ? json.error : 'İstek tamamlanamadı. Lütfen tekrar deneyin.');
        })
        .catch(function(){
          setStatus('');
          setResult(q, 'Ağ hatası. Lütfen tekrar deneyin.');
        })
        .finally(function(){
          setLoading(false);
          setTimeout(function(){ input && input.focus(); }, 80);
        });
    }

    btn.addEventListener('click', function(){
      var q = (input.value || '').trim();
      if (!q) { setResult('Soru', 'Lütfen bir arama terimi yazın.'); return; }
      request(q);
    });

    input.addEventListener('keydown', function(e){
      if (e.key === 'Enter') btn.click();
    });
  }

  function initAll(){
    var nodes = document.querySelectorAll('.ag-llm-search');
    nodes.forEach(function(node){ initWidget(node); });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }
})();
